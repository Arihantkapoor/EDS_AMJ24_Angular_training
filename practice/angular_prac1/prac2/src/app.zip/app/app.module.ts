import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { PipesComponent } from './Pipes/Pipes.component';
import { TitlePipe } from './title.pipe';

@NgModule({
  declarations: [		
    AppComponent,
      PipesComponent,
      TitlePipe
   ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
