/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TitlePipe } from './title.pipe';

describe('Pipe: Titlee', () => {
  it('create an instance', () => {
    let pipe = new TitlePipe();
    expect(pipe).toBeTruthy();
  });
});
