import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { MatButtonModule } from '@angular/material/button';
// import { MatButtonToggleModule } from '@angular/material/button-toggle';
// import { MatBadgeModule } from '@angular/material/badge';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    // MatButtonModule,
    // MatBadgeModule,
    // MatButtonToggleModule,
  ],
  // exports: [MatButtonModule, MatButtonToggleModule, MatBadgeModule],
})
export class MaterialModule {}
