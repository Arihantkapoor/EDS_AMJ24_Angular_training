import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Sales',
  templateUrl: './Sales.component.html',
  styleUrls: ['./Sales.component.css']
})
export class SalesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
