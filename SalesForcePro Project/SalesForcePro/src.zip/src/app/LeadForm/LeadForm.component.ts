import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-LeadForm',
  templateUrl: './LeadForm.component.html',
  styleUrls: ['./LeadForm.component.css']
})
export class LeadFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
