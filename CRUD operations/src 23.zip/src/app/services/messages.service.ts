import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MessagesService {

  constructor(private http:HttpClient) { }
  getmsg():String[]{
    return ["1","2","3"];
  }
  getapi(){
    return this.http.get('https://jsonplaceholder.org/users');
  }

}
