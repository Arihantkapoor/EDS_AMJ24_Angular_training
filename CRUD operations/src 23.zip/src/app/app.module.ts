import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { ProductComponent } from './product/product.component';
import { RegisterComponent } from './Register/Register.component';
import { LoginComponent } from './Login/Login.component';
import{MessagesService} from './services/messages.service';

@NgModule({
  declarations: [			
    AppComponent,
      ProductComponent,
      RegisterComponent,
      LoginComponent
   ],
  imports: [
    BrowserModule,HttpClientModule,FormsModule, ReactiveFormsModule
  ],
  providers: [MessagesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
