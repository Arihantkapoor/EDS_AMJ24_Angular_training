export class product{
    id:number;
    name:string;
    price:number;
}