import { HttpClient } from '@angular/common/http';
import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { product } from './product';
import { StudentServiceService } from '../services/student-service.service';
import { Observable, map} from 'rxjs';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnChanges  {

  ProductList:any=[];
  name:string;
  price:number;

  students:any[]=[];

  obj=new Observable((res)=>{
    res.next(this.students)
  }).pipe(
    
  )

 

  constructor(private http:HttpClient,private serv:StudentServiceService) {
    
    // this.serv.getStudent().subscribe(
    //   (data:any)=>{
    //     this.students=data;
    //   }
    // )
    this.loaddata();
   }
  ngOnChanges(changes: SimpleChanges): void {
  
    this.loaddata();
    
  }


   loaddata(){
    this.http.get('http://localhost:62912/api/Product/GetProduct').subscribe(
      data=>{
        this.ProductList=data;
      }
    )
   }

   createItem(){
    if(this.name!="" && this.price>0){
      let obj=new product;
      obj.name=this.name;
      obj.price=this.price;
      this.http.post('http://localhost:62912/api/Product/PostProduct',obj).subscribe(
        (res)=>{
          console.log(res);
        },
        (error)=>{
          console.log(error);
        }
      )

    }
   
   }

   update(p:product){
    console.log("from ui "+p);
    let pri=prompt("change price of the product: product name : "+p.name,String(p.price))
    p.price=Number(pri);
    this.http.put('http://localhost:62912/api/Product/UpdateProduct',p).subscribe(
      data=>{
        alert("I got the data");
        console.log(data);
      }
    )
   }
   delete(pid:number){
    this.http.delete('http://localhost:62912/api/Product/DeleteProduct?id='+pid).subscribe(
      data=>{
        console.log(data);
      }
    )
   }

  

}
