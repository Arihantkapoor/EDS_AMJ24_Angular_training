import { Component,OnInit } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import { MessagesService } from './services/messages.service';
import { FormGroup, FormControl,  
  FormArray, Validators,FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements  OnInit{
  title = 'ang162';
  posts:any;
  form:any;
  n:number=17;
  today:number=Date.now(); 
  msgs:String[]=[];
  api:any;

  constructor(private http:HttpClient,private fb:FormBuilder,private msg:MessagesService){
    this.form = this.fb.group({
      name: ['', Validators.required],    
      mobile: ['', Validators.required]
    });
    this.msgs=msg.getmsg();
    this.api=msg.getapi();
    msg.getapi().subscribe((response)=>{
      console.log(response);
      this.api=response;
    })

  }
  setDelete(data: any)
  {
    this.http.delete("http://localhost:62912/api/Users/DeleteUser"+ "/"+ data.id).subscribe((resultData: any)=>
    {
        console.log(resultData);
        alert("Student Deletedddd")
        this.ngOnInit();
    });
  }
  Create(){
    console.log(this.form);
    if(this.form.valid){
      const data=this.form.value;
      this.http.post('http://localhost:62912/api/Users/Postusers',data).subscribe((response)=>{
      console.log(response);
      this.posts=response;
      this.ngOnInit();
    })
    this.form.reset();
    }
    
  }
  ngOnInit(){
    
    this.http.get('http://localhost:62912/api/Users/Getusers').subscribe((response)=>{
      console.log(response);
      this.posts=response;
    })
  }
  data:any;
  getjsondata(){
    this.http.get('./data.json').subscribe((response)=>{
      console.log(response);
      this.data=response;
    })
  }
  updatedele:any;
  updateUser(index:number,obj:any){
    this.updatedele=prompt("Enter name to update",obj.name);
    obj.name=this.updatedele;
    this.http.patch('http://localhost:62912/api/Users/UpdateUser',obj).subscribe(
      res=>{
        console.log(res);
      }
    );
  }
  flag:boolean=false;
  userorproductdisplay(){
    this.flag=!this.flag;
  }
}
