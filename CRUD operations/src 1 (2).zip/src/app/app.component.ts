import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './Services/employee.service';
import { Employee } from './Models/Employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  employeeList:Employee[]=[]
  constructor(private empserv:EmployeeService)
  {

  }
  ngOnInit(): void {
    this.empserv.getEmployees().subscribe(data=>
      this.employeeList = data
    )
  }
  title = 'Angular_Core';
}
