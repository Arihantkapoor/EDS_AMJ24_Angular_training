export class Employee {
    id:string;
    name:string
}
