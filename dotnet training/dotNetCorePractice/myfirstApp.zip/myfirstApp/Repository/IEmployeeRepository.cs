using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using myfirstApp.Models;

namespace myfirstApp.Repository
{
    public interface IEmployeeRepository
    {
        IEnumerable<Employee> getAllEmployees();

        int saveEmployee(Employee emp);

        int updateEmployee(Employee emp, int id);

        int deleteEmployee(int id);

        Employee searchEmployee(int id);
    }
}