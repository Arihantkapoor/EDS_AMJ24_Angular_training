using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using myfirstApp.Controllers;
using myfirstApp.DAL;
using myfirstApp.Models;

namespace myfirstApp.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        EmployeeDBContext context;
        public EmployeeRepository(EmployeeDBContext _context)
        {
            context = _context;
        }
        int IEmployeeRepository.deleteEmployee(int id)
        {
            throw new NotImplementedException();
        }

        IEnumerable<Employee> IEmployeeRepository.getAllEmployees()
        {
           return context.employees.ToList();
        }

        int IEmployeeRepository.saveEmployee(Employee emp)
        {
            throw new NotImplementedException();
        }

        Employee IEmployeeRepository.searchEmployee(int id)
        {
            throw new NotImplementedException();
        }

        int IEmployeeRepository.updateEmployee(Employee emp, int id)
        {
            throw new NotImplementedException();
        }
    }
}